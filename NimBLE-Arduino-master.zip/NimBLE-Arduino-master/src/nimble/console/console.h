#ifndef __CONSOLE_H__
#define __CONSOLE_H__

#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

#define console_printf printf

#ifdef __cplusplus
}
#endif

#endif /* __CONSOLE_H__ */